package PExact;

import Suporte.Generator;
import Suporte.Screenshot;
import Suporte.Web;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import static java.util.concurrent.TimeUnit.SECONDS;
import static org.junit.Assert.assertEquals;


public class TestesExact {
    private WebDriver navegador;
    @Rule
    public TestName test = new TestName();

    @Before
    public void setup() {
        navegador = Web.TelaInicialweb();
        //Abrindo Navegador Maximizado
        navegador.manage().window().maximize();

    }

    @Test
    public void PreenchimentosDosCampos() throws InterruptedException {

        JavascriptExecutor js = (JavascriptExecutor) navegador;

        Thread.sleep(5000);
        //Verificando se está na pagina correta
        navegador.manage().timeouts().implicitlyWait(10, SECONDS);
        //Verificando o Titulo da pagina
        WebElement TopoDaPagina = navegador.findElement(By.xpath("//*[@id=\"header\"]/nav/div/div[2]/ul/li[2]"));

        WebElement CampoRefresh = navegador.findElement(By.xpath("//*[@id=\"Button1\"]"));
        Thread.sleep(1000);


        js.executeScript("arguments[0].scrollIntoView();", CampoRefresh);
        Thread.sleep(1000);
        CampoRefresh.click();
        Thread.sleep(1000);

       // js.executeScript("arguments[0].scrollIntoView();", FullName);
        Thread.sleep(1000);



        WebElement Submit = navegador.findElement(By.xpath("//*[@id=\"submitbtn\"]"));
        Thread.sleep(5000);





        Thread.sleep(5000);
        WebElement CampoName = navegador.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[1]/div[1]/input"));
        Thread.sleep(1000);
        CampoName.sendKeys("Myke");


        Thread.sleep(5000);
        js.executeScript("arguments[0].scrollIntoView();", CampoName);

        Thread.sleep(1000);
        String screenshotArquivo1 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo nome sem sobrenome "+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo1);
        Thread.sleep(1000);
        CampoName.clear();
        Thread.sleep(1000);
        //Teste com erro de preenchimento
        CampoName.sendKeys("@");

        String screenshotArquivo2 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo nome somente com caracteres - Erro"+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo2);

        Thread.sleep(1000);

        WebElement CampoSobreNome = navegador.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[1]/div[2]/input"));
        Thread.sleep(1000);
        CampoSobreNome.sendKeys("Leal");
        String screenshotArquivo3 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo sobrenome "+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo3);
        Thread.sleep(1000);
        CampoSobreNome.clear();
        Thread.sleep(1000);
        // Teste Com erro de preenchimento
        CampoSobreNome.sendKeys("*");
        String screenshotArquivo4 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo sobrenome somente com caracteres - Erro"+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo4);


        WebElement CampoEndereco = navegador.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[2]/div/textarea"));
        Thread.sleep(1000);
        CampoEndereco.sendKeys("Rua Vista Alrea Tulipa 2456");
        String screenshotArquivo5 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo Endereço "+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo5);
        Thread.sleep(1000);

        WebElement ExigenciaCompletaDoCampoEmail = navegador.findElement(By.xpath("//*[@id=\"eid\"]/input"));
        Thread.sleep(1000);
        ExigenciaCompletaDoCampoEmail.sendKeys("mm");
        String screenshotArquivo6 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo Email imcompleta "+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo6);
        Thread.sleep(5000);

        //Scrool para ver verificação
        js.executeScript("arguments[0].scrollIntoView();", Submit);
        Submit.click();
        Thread.sleep(2000);
        js.executeScript("arguments[0].scrollIntoView();", CampoEndereco);
        String screenshotArquivo7 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo Email mensagem de erro "+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo7);
        Thread.sleep(3000);

        ExigenciaCompletaDoCampoEmail.clear();

        //Erro faltando .com no email e deixa passar
        WebElement CampoEmailFaltando = navegador.findElement(By.xpath("//*[@id=\"eid\"]/input"));
        Thread.sleep(2000);
        CampoEmailFaltando.sendKeys("myckeleal@gmail");
        String screenshotArquivo8 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo Email faltando .com - Erro "+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo8);
        Thread.sleep(1000);
        CampoEmailFaltando.clear();

        WebElement CampoEmail = navegador.findElement(By.xpath("//*[@id=\"eid\"]/input"));
        Thread.sleep(2000);
        CampoEmail.sendKeys("myckeleal@gmail.com");
        String screenshotArquivo9 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo Email "+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo9);
        Thread.sleep(1000);

        WebElement CampoPhone = navegador.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[4]/div/input"));
        Thread.sleep(2000);
        CampoPhone.sendKeys("984707808");
        String screenshotArquivo10 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo Phone com 984707808 "+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo10);
        Thread.sleep(1000);
        js.executeScript("arguments[0].scrollIntoView();", Submit);
        Submit.click();
        Thread.sleep(2000);
        js.executeScript("arguments[0].scrollIntoView();", CampoEmail);
        String screenshotArquivo11 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo Phone com 984707808 mensagem de erro "+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo11);
        Thread.sleep(1000);

        CampoPhone.clear();
        Thread.sleep(1000);

        CampoPhone.sendKeys("31984707808");
        String screenshotArquivo12 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo Phone com 31984707808 "+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo12);
        Thread.sleep(1000);
        js.executeScript("arguments[0].scrollIntoView();", Submit);
        Submit.click();
        Thread.sleep(2000);
        js.executeScript("arguments[0].scrollIntoView();", CampoEmail);
        String screenshotArquivo13 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo Phone com 31984707808 mensagem de erro "+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo13);
        Thread.sleep(1000);


        CampoPhone.clear();
        Thread.sleep(1000);

        CampoPhone.sendKeys("3135334525");
        String screenshotArquivo14 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo Phone com 3135334525 - Correto "+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo14);
        Thread.sleep(1000);
        js.executeScript("arguments[0].scrollIntoView();", Submit);
        Submit.click();
        Thread.sleep(1000);
        js.executeScript("arguments[0].scrollIntoView();", CampoEmail);
        String screenshotArquivo15 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Preenchimento do campo Phone com 3135334525 - Correto "+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo15);
        Thread.sleep(1000);


        WebElement CampoGender = navegador.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[5]/div/label[1]/input"));
        Thread.sleep(2000);
        CampoGender.click();
        String screenshotArquivo16 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Selecionando campo Gender"+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo16);
        Thread.sleep(1000);


        WebElement CampoHobies1 = navegador.findElement(By.xpath("//*[@id=\"checkbox1\"]"));
        Thread.sleep(2000);
        CampoHobies1.click();
        String screenshotArquivo17 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Selecionando checkbox Cricket"+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo17);
        Thread.sleep(1000);

        WebElement CampoHobies2 = navegador.findElement(By.xpath("//*[@id=\"checkbox2\"]"));
        Thread.sleep(2000);
        CampoHobies2.click();
        String screenshotArquivo18 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Selecionando checkbox Movies"+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo18);
        Thread.sleep(1000);


        WebElement CampoHobies3 = navegador.findElement(By.xpath("//*[@id=\"checkbox3\"]"));
        Thread.sleep(2000);
        CampoHobies3.click();
        String screenshotArquivo19 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Selecionando checkbox Hockey"+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo19);
        Thread.sleep(1000);


        WebElement CampoLanguagen = navegador.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[7]/div/multi-select"));
        Thread.sleep(3000);

        CampoLanguagen.click();

        Thread.sleep(5000);

        WebElement CampoLanguagen1 = navegador.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[7]/div/multi-select/div[2]/ul/li[29]/a"));
        Thread.sleep(2000);
        CampoLanguagen1.click();
        String screenshotArquivo20 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Selecionando primeira linguagem"+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo20);
        Thread.sleep(1000);


        WebElement CampoLanguagen2 = navegador.findElement(By.xpath("//*[@id=\"basicBootstrapForm\"]/div[7]/div/multi-select/div[2]/ul/li[8]/a"));
        Thread.sleep(2000);
        CampoLanguagen2.click();
        String screenshotArquivo21 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Selecionando segunda linguagem"+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo21);
        Thread.sleep(1000);

        WebElement ClickGeral= navegador.findElement(By.xpath("//*[@id=\"section\"]/div/div"));
        Thread.sleep(2000);
        ClickGeral.click();

        WebElement CampoSkills= navegador.findElement(By.xpath("//*[@id=\"section\"]/div/div"));
        Thread.sleep(2000);
        CampoSkills.click();
        String screenshotArquivo22 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Selecionando Campo Skills"+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo22);
        Thread.sleep(1000);

        WebElement CampoSkills2= navegador.findElement(By.xpath("//*[@id=\"Skills\"]/option[23]"));
        Thread.sleep(2000);
        CampoSkills2.click();


        WebElement CampoCountry= navegador.findElement(By.xpath("//*[@id=\"countries\"]"));
        Thread.sleep(2000);
        CampoCountry.click();
        String screenshotArquivo23 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Selecionando Campo Country"+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo23);
        Thread.sleep(1000);

        js.executeScript("arguments[0].scrollIntoView();", Submit);
        Submit.click();
        Thread.sleep(2000);
        js.executeScript("arguments[0].scrollIntoView();", CampoSkills);
        String screenshotArquivo24 = "C:\\Users\\linda\\Downloads\\Testes Executasdos Para Exact\\Automatizado\\Screenshots\\"+"Data"+ Generator.dataHoraParaArquivo() + "Teste"+ test.getMethodName() + "Obs"+"Campo Country faltando opção "+ ".png";
        Screenshot.takescreenshot(navegador,screenshotArquivo24);
        Thread.sleep(3000);


    }



}