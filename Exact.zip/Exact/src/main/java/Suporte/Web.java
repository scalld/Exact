package Suporte;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Web {
    public static WebDriver TelaInicialweb()
    {
        //Abrindo Navegador
        String string = System.setProperty("webdriver.chrome.driver", "C:\\Users\\linda\\Desktop\\Estudo\\Automação de Testes\\Chromedriver\\chromedriver-win32\\chromedriver.exe");
        WebDriver navegador = new ChromeDriver();
        //Abrindo Navegador com endereço
        navegador.get("http://demo.automationtesting.in/Register.html");

        return navegador;

    }


}

