package Suporte;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;



public class Generator {
    public static <String> String dataHoraParaArquivo(){
        Timestamp ts = new Timestamp(System.currentTimeMillis());
        return (String) new SimpleDateFormat("yyyyMMddhhmmss").format(ts);
    }
}
